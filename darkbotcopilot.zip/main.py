import yaml
from darkbot.agent import DarkBotAgent
from darkbot.stream import SensorStream
from ui.tui import TerminalUI

def load_config():
    with open("config.yaml") as f:
        return yaml.safe_load(f)

def main():
    config = load_config()
    agent = DarkBotAgent(config)
    stream = SensorStream(agent)
    ui = TerminalUI(agent, stream)
    ui.run()

if __name__ == "__main__":
    main()