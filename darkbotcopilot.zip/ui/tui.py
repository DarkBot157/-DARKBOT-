from rich.console import Console

class TerminalUI:
    def __init__(self, agent, stream):
        self.agent = agent
        self.stream = stream
        self.console = Console()

    def run(self):
        self.console.print("[bold blue]DARKBOT™ AI Lab: Terminal Mode[/bold blue]")
        while True:
            user_input = input("> ")
            if user_input == "exit":
                break
            if user_input.startswith("/ritual "):
                command = user_input[len("/ritual "):]
                output = self.agent.execute(command)
            else:
                output = self.agent.perceive(user_input)
            self.console.print(f"[green]{output}[/green]")