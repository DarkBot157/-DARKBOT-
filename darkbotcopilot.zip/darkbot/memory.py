import chromadb

class Memory:
    def __init__(self, config):
        self.client = chromadb.PersistentClient(path=config["persist_path"])
        self.collection = self.client.get_or_create_collection("darkbot_memory")

    def store(self, text, meta=None):
        # Store text with optional metadata
        self.collection.add(documents=[text], metadatas=[meta or {}])

    def recall(self, query, top_k=5):
        # Vector search for relevant memories
        results = self.collection.query(query_texts=[query], n_results=top_k)
        return results['documents'][0] if results['documents'] else []