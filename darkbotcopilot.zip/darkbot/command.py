import json

class CommandExecutor:
    def __init__(self, agent):
        self.agent = agent
        with open("tasks.json") as f:
            self.tasks = json.load(f)

    def run(self, command, agent=None):
        # Match and execute rituals from tasks.json
        for task in self.tasks:
            if task["trigger"] == command:
                results = []
                for action in task["actions"]:
                    # This could eval symbolic, memory, llm, etc.
                    # Example: "symbolic.tune(369)"
                    results.append(eval(f"agent.{action}"))
                return results
        return f"No ritual found for '{command}'"