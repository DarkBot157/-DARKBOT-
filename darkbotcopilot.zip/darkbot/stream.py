class SensorStream:
    def __init__(self, agent):
        self.agent = agent

    def simulate_input(self, stream_type, value):
        data = {"type": stream_type, "value": value}
        return self.agent.perceive(data)