from .memory import Memory
from .llm import OllamaLLM
from .tools import ToolRegistry
from .command import CommandExecutor
from .symbolic import SymbolicLayer

class DarkBotAgent:
    def __init__(self, config):
        self.config = config
        self.memory = Memory(config["memory"])
        self.llm = OllamaLLM(config["agent"]["llm_model"])
        self.tools = ToolRegistry(config["tools"])
        self.commands = CommandExecutor(self)
        self.symbolic = SymbolicLayer(config["agent"]["symbolic_nodes"])
        self.state = {}
    
    def perceive(self, input_data):
        # Handle input (text, voice, sensor, emotional)
        self.memory.store(input_data, meta={"type": "input"})
        symbolic_state = self.symbolic.map_state(input_data)
        response = self.llm.generate_response(input_data, symbolic_state)
        self.memory.store(response, meta={"type": "response"})
        return response
    
    def execute(self, command):
        return self.commands.run(command, agent=self)