import ollama

class OllamaLLM:
    def __init__(self, model="llama3"):
        self.model = model

    def generate_response(self, prompt, context=None):
        # Use context for system prompt if given
        system_prompt = f"Context: {context}\n" if context else ""
        response = ollama.chat(model=self.model, messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ])
        return response['message']['content']